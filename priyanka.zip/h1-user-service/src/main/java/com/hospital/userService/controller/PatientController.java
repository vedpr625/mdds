
	package com.hospital.userService.controller;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.*;

import com.hospital.userService.exception.ResourceNotFoundException;
import com.hospital.userService.model.Patient;
import com.hospital.userService.repository.PatientRepository;

import javax.validation.Valid;
	import java.util.List;

	@RestController
	@RequestMapping("/api")
	public class PatientController {

	    @Autowired
	    PatientRepository patientRepository;

	    @GetMapping("/patients")
	    public List<Patient> getAllPatients() {
	        return patientRepository.findAll();
	    }
	    
	   
	    @PostMapping("/patients")
	    public Patient createPatients(@Valid @RequestBody Patient patient) {
	        return patientRepository.save(patient);
	    }

	    @GetMapping("/patients/{id}")
	    public Patient getPatientById(@PathVariable(value = "id") Long patientId) {
	        return patientRepository.findById(patientId)
	                .orElseThrow(() -> new ResourceNotFoundException("Patient", "id", patientId));
	    }

	    @PutMapping("/patients/{id}")
	     public Patient updatePatient(@PathVariable(value = "id") Long patientId,
	                                           @Valid @RequestBody Patient patientDetails) {

	        Patient patient = patientRepository.findById(patientId)
	                .orElseThrow(() -> new ResourceNotFoundException("Patient", "id", patientId));

	       patient.setPatientName(patientDetails.getPatientName());
	       patient.setPatientAge(patientDetails.getPatientAge());
	       patient.setBirthOrder(patientDetails.getBirthOrder());
	       patient.setParity(patientDetails.getParity());
	       patient.setGravida(patientDetails.getGravida());
	       patient.setIdentityUnknownIndicator(patientDetails.getIdentityUnknownIndicator());
	       patient.setCauseOfDeathKnownIndicator(patientDetails.getCauseOfDeathKnownIndicator());
	       patient.setPatientAddress(patientDetails.getPatientAddress());
	       patient.setPatientAddressType(patientDetails.getPatientAddressType());
	       patient.setPatientLandlineNumber(patientDetails.getPatientLandlineNumber());
	       patient.setPatientMobileNumber(patientDetails.getPatientMobileNumber());
	       patient.setPatientClass(patientDetails.getPatientClass());
	       patient.setPatientArrivalTime(patientDetails.getPatientArrivalTime());
	       patient.setPatientArrivalDate(patientDetails.getPatientArrivalDate());
	       patient.setReasonForVisit(patientDetails.getReasonForVisit());
	       patient.setPregnancyIndicator(patientDetails.getPregnancyIndicator());
	       patient.setDurationOfPregnancy(patientDetails.getDurationOfPregnancy());


	        Patient updatedPatient = patientRepository.save(patient);
	        return updatedPatient;
	    }

	    @DeleteMapping("/patients/{id}")
	    public ResponseEntity<?> deleteNote(@PathVariable(value = "id") Long patientId) {
	        Patient patient = patientRepository.findById(patientId)
	                .orElseThrow(() -> new ResourceNotFoundException("Patient", "id", patientId));

	        patientRepository.delete(patient);

	        return ResponseEntity.ok().build();
	    }
	}
