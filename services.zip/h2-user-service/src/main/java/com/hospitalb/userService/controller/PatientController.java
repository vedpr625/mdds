
	package com.hospitalb.userService.controller;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.*;

import com.hospitalb.userService.exception.ResourceNotFoundException;
import com.hospitalb.userService.model.Patient;
import com.hospitalb.userService.repository.PatientRepository;

import javax.validation.Valid;
	import java.util.List;

	@RestController
	@RequestMapping("/api")
	public class PatientController {

	    @Autowired
	    PatientRepository patientRepository;

	    @GetMapping("/patients")
	    public List<Patient> getAllPatients() {
	        return patientRepository.findAll();
	    }

	    @PostMapping("/patients")
	    public Patient createPatients(@Valid @RequestBody Patient patient) {
	        return patientRepository.save(patient);
	    }

	    @GetMapping("/patients/{id}")
	    public Patient getPatientById(@PathVariable(value = "id") Long patientId) {
	        return patientRepository.findById(patientId)
	                .orElseThrow(() -> new ResourceNotFoundException("Patient", "id", patientId));
	    }

	    @PutMapping("/patients/{id}")
	     public Patient updatePatient(@PathVariable(value = "id") Long patientId,
	                                           @Valid @RequestBody Patient patientDetails) {

	        Patient patient = patientRepository.findById(patientId)
	                .orElseThrow(() -> new ResourceNotFoundException("Patient", "id", patientId));

	       patient.setPatient_name(patientDetails.getPatient_name());
	       patient.setPatient_age(patientDetails.getPatient_age());
	       patient.setBirth_order(patientDetails.getBirth_order());
	       patient.setParity(patientDetails.getParity());
	       patient.setGravida(patientDetails.getGravida());
	       patient.setIdentity_unknown_indicator(patientDetails.getIdentity_unknown_indicator());
	       patient.setCause_of_death_known_indicator(patientDetails.getCause_of_death_known_indicator());
	       patient.setPatient_address(patientDetails.getPatient_address());
	       patient.setPatient_addressType(patientDetails.getPatient_addressType());
	       patient.setPatient_landline_number(patientDetails.getPatient_landline_number());
	       patient.setPatient_mobile_number(patientDetails.getPatient_mobile_number());
	       patient.setPatient_class(patientDetails.getPatient_class());
	       patient.setPatient_arrival_time(patientDetails.getPatient_arrival_time());
	       patient.setPatient_arrival_date(patientDetails.getPatient_arrival_date());
	       patient.setReason_for_visit(patientDetails.getReason_for_visit());
	       patient.setPregnancy_indicator(patientDetails.getPregnancy_indicator());
	       patient.setDuration_of_pregnancy(patientDetails.getDuration_of_pregnancy());


	        Patient updatedPatient = patientRepository.save(patient);
	        return updatedPatient;
	    }

	    @DeleteMapping("/patients/{id}")
	    public ResponseEntity<?> deleteNote(@PathVariable(value = "id") Long patientId) {
	        Patient patient = patientRepository.findById(patientId)
	                .orElseThrow(() -> new ResourceNotFoundException("Patient", "id", patientId));

	        patientRepository.delete(patient);

	        return ResponseEntity.ok().build();
	    }
	}
