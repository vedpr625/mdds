package com.hospitalb.userService.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreType;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonProperty;


@Getter
@Setter
@Entity
@Table(name="hospitalb_patient")
@JsonIgnoreProperties(ignoreUnknown = true, value = {"id"})

public class Patient  {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	Long ID;
	
	@JsonProperty("05.003.0001")
	@JsonAlias("patient_iD")
	@Column(length=18)
	String patient_id;
	
	@JsonProperty("05.003.0002")
	@JsonAlias("patient_name")
	String patient_name;
	
	@JsonProperty("05.003.0003")
	@JsonAlias("patient_age")
	@Column(length=7)
	int patient_age;
	
	@JsonProperty("05.003.0004")
	@JsonAlias("birth_order")
	@Column(length=1)
    int birth_order;
	
	@JsonProperty("05.003.0005")
	@JsonAlias("parity")
	@Column(length=2)
	int parity;
	
	@JsonProperty("05.003.0006")
	@JsonAlias("gravida")
	@Column(length=2)
	int gravida;
	
	@JsonProperty("05.003.0007")
	@JsonAlias("identity_unknown_indicator")
	@Column(length=1)
	int identity_unknown_indicator;
	
	@JsonProperty("05.003.0008")
	@JsonAlias("cause_of_death_known_indicator")
	@Column(length=2)
	int cause_of_death_known_indicator;
	
	@JsonProperty("05.003.0009")
	@JsonAlias("patient_address")
	String patient_address;
	
	@JsonProperty("05.003.00010")
	@JsonAlias("patient_addressType")
	@Column(length=1)
	String patient_addressType;
	
	@JsonProperty("05.003.00011")
	@JsonAlias("patient_landline_number")
	int patient_landline_number;
	
	@JsonProperty("05.003.00012")
	@JsonAlias("patient_mobile_number")
	int patient_mobile_number;
	
	@JsonProperty("05.003.00013")
	@JsonAlias("patient_class")
	@Column(length=2)
	int patient_class;
	
	@JsonProperty("05.003.00014")
	@JsonAlias("patient_arrival_time")
	@Column(length=8)
	String patient_arrival_time;
	
	@JsonProperty("05.003.00015")
	@JsonAlias("patient_arrival_date")
	String patient_arrival_date;
	
	@JsonProperty("05.003.00016")
	@JsonAlias("reason_for_visit")
	@Column(length=99)
	String reason_for_visit;
	
	@JsonProperty("05.003.00017")
	@JsonAlias("pregnancy_indicator")
	@Column(length=1)
	int pregnancy_indicator;
	
	@JsonProperty("05.003.00018")
	@JsonAlias("duration_of_pregnancy")
	@Column(length=2)
	int duration_of_pregnancy;
	
}
