package com.hospital.userService.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table
@JsonIgnoreProperties(ignoreUnknown = true, value = {"id"})

public class Patient  {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	Long ID;
	
	@JsonProperty("05.003.0001")
	@JsonAlias("patientID")
	@Column(length=18)
	String patientID;
	
	@JsonProperty("05.003.0002")
	@JsonAlias("patientName")
	String patientName;
	
	@JsonProperty("05.003.0003")
	@JsonAlias("patientAge")
	@Column(length=7)
	int patientAge;
	
	@JsonProperty("05.003.0004")
	@JsonAlias("birthOrder")
	@Column(length=1)
    int birthOrder;
	
	@JsonProperty("05.003.0005")
	@JsonAlias("parity")
	@Column(length=2)
	int parity;
	
	@JsonProperty("05.003.0006")
	@JsonAlias("gravida")
	@Column(length=2)
	int gravida;
	
	@JsonProperty("05.003.0007")
	@JsonAlias("identityUnknownIndicator")
	@Column(length=1)
	int identityUnknownIndicator;
	
	@JsonProperty("05.003.0008")
	@JsonAlias("causeOfDeathKnownIndicator")
	@Column(length=2)
	int causeOfDeathKnownIndicator;
	
	@JsonProperty("05.003.0009")
	@JsonAlias("patientAddress")
	String patientAddress;
	
	@JsonProperty("05.003.0010")
	@JsonAlias("patientAddressType")
	@Column(length=1)
	String patientAddressType;
	
	@JsonProperty("05.003.0011")
	@JsonAlias("patientLandlineNumber")
	int patientLandlineNumber;
	
	@JsonProperty("05.003.0012")
	@JsonAlias("patientMobileNumber")
	int patientMobileNumber;
	
	@JsonProperty("05.003.0013")
	@JsonAlias("patientClass")
	@Column(length=2)
	int patientClass;
	
	@JsonProperty("05.003.0014")
	@JsonAlias("patientArrivalTime")
	@Column(length=8)
	String patientArrivalTime;
	
	@JsonProperty("05.003.0015")
	@JsonAlias("patientArrivalDate")
	String patientArrivalDate;
	
	@JsonProperty("05.003.0016")
	@JsonAlias("reasonForVisit")
	@Column(length=99)
	String reasonForVisit;
	
	@JsonProperty("05.003.0017")
	@JsonAlias("pregnancyIndicator")
	@Column(length=1)
	int pregnancyIndicator;
	
	@JsonProperty("05.003.0018")
	@JsonAlias("durationOfPregnancy")
	@Column(length=2)
	int durationOfPregnancy;
	
}
